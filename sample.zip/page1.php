<!DOCTYPE HTML> 
<html> 
    
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <script src="bootstrap/js/bootstrap.min.js"></script>
    <script src="js/jquery-3.5.1.min.js"></script>
    <body> 
        <h4 id="demo"></h4>
  
    </body> 

    <script> 
            var deadline = new Date("Nov 11, 2020 14:25:00").getTime(); 
            var y = setInterval(function() 
            { 
                var now = new Date().getTime(); 
                var t = deadline - now; 
                
                var minutes = Math.floor((t % (1000 * 60 * 60)) / (1000 * 60)); 
                var seconds = Math.floor((t % (1000 * 60)) / 1000); 
            
                document.getElementById("demo").innerHTML = "Adzan counter " + minutes + "m " + seconds + "s "; 
                
                if (t < 0) { 
                    clearInterval(y); 
                    document.getElementById("demo").innerHTML = ""; 
                    iqomah();
                 
                }
            },1000);


        function iqomah() {

        
            var deadline = new Date("Nov 11, 2020 14:28:00").getTime(); 
            var z = setInterval(function() 
            { 
                var now = new Date().getTime(); 
                var t = deadline - now; 
                
                var minutes = Math.floor((t % (1000 * 60 * 60)) / (1000 * 60)); 
                var seconds = Math.floor((t % (1000 * 60)) / 1000); 
            
                document.getElementById("demo").innerHTML = "Iqomah counter " + minutes + "m " + seconds + "s "; 
                
                if (t < 0) { 
                    clearInterval(z); 

                    document.getElementById("demo").innerHTML = "Waktu Sholat "; 

                    //window.open("http://172.16.10.10/imasjid-develop","_self");

                }
            },1000);
                   
        }    


        </script> 

</html> 