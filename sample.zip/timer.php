<!DOCTYPE HTML> 
<html> 
    <head> 
        
    </head> 
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <script src="bootstrap/js/bootstrap.min.js"></script>
    <script src="js/jquery-3.5.1.min.js"></script>
    <body> 
        <h4 id="demo"></h4>

        <script> 
            var deadline = new Date("Nov 11, 2020 13:20:00").getTime(); 
            var x = setInterval(function() 
            { 
                var now = new Date().getTime(); 
                var t = deadline - now; 
               
                var minutes = Math.floor((t % (1000 * 60 * 60)) / (1000 * 60)); 
                var seconds = Math.floor((t % (1000 * 60)) / 1000); 
            
                document.getElementById("demo").innerHTML = minutes + "m " + seconds + "s "; 
            
                if (t < 0) { 
                    clearInterval(x); 
                    document.getElementById("demo").innerHTML = ""; 
                    window.open("http://172.16.10.10/sample/page1.php","_self");
                } 
            }, 1000); 
        </script> 
  
    </body> 
</html> 